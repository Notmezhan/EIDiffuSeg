"""
Codebase for " Diffusion Models for Implicit Image Segmentation Ensembles".
"""
